# Calculator ReactJS

This is a simple arithmetic calculator built with REACT.JS library. 

Live version deployed at [heroku](https://calculator-n.herokuapp.com/)

To run it on your local machine clone into the repo, then type: 

    npm install && npm start
    
    
A sneak peek: 

![alt react-calculator-simple](Screenshot.png)



